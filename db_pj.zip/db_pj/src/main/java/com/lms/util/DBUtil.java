package com.lms.util;

import java.sql.*;

public class DBUtil {

    // user1@orclpdb 계정에 연결
    private static final String URL = "jdbc:oracle:thin:@localhost:1521/orclpdb";
    private static final String USER = "user1"; 
    private static final String PW = "Oracle#19c";  // ← 여기에 user1 비밀번호 넣기

    public static Connection getConnection() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            return DriverManager.getConnection(URL, USER, PW);
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
