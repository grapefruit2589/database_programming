package com.lms.model;

public class Subject {

    private int enrollId;      // 수강ID
    private String code;       // 과목코드
    private String name;       // 과목명
    private String achievement; // 성적비율 or 성취도

    // ---- 추가해야 하는 부분 ----
    public int getEnrollId() {
        return enrollId;
    }

    public void setEnrollId(int enrollId) {
        this.enrollId = enrollId;
    }
    // ------------------------------

    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getAchievement() {
        return achievement;
    }
    public void setAchievement(String achievement) {
        this.achievement = achievement;
    }
}