package com.lms.controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.lms.dao.AchievementDAO;

public class AchievementServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // 세션에서 학번 가져오기 (int 또는 String 모든 경우에 안전)
        Object studentObj = req.getSession().getAttribute("studentNo");

        if (studentObj == null) {
            resp.getWriter().println("로그인이 필요합니다.");
            return;
        }

        String studentNo = String.valueOf(studentObj);  // ← 핵심 포인트

        AchievementDAO dao = new AchievementDAO();

        req.setAttribute("courses", dao.getCourseAchievements(studentNo));
        req.setAttribute("activities", dao.getActivityAchievements(studentNo));

        req.getRequestDispatcher("achievement.jsp").forward(req, resp);
    }
}
