package com.lms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.lms.dao.SubjectDAO;
import com.lms.model.Subject;

@WebServlet("/main")
public class SubjectListServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();
        Object obj = session.getAttribute("studentNo");

        // 로그인 안 되어 있으면 로그인 페이지로
        if (obj == null) {
            resp.sendRedirect("index.jsp");
            return;
        }

        int studentNo = (int) obj;

        SubjectDAO dao = new SubjectDAO();
        // 수강중인 과목 + 성적비율 조회
        List<Subject> list = dao.getCurrentSubjects(studentNo);

        req.setAttribute("subjects", list);
        req.getRequestDispatcher("main.jsp").forward(req, resp);
    }
}
