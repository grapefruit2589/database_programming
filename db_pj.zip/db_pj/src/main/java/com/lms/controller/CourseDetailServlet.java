package com.lms.controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.*;

import com.lms.dao.SubjectDAO;


@WebServlet("/courseDetail")
public class CourseDetailServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        int sid = Integer.parseInt(req.getParameter("sid"));

        SubjectDAO dao = new SubjectDAO();

        req.setAttribute("detail", dao.getCourseDetail(sid));
        req.setAttribute("students", dao.getStudentsByCourse(sid));

        req.getRequestDispatcher("course_detail.jsp").forward(req, resp);
    }
}

