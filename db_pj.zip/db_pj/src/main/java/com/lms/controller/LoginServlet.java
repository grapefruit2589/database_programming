package com.lms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.lms.dao.LoginDAO;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        String studentNo = req.getParameter("studentNo");
        String password = req.getParameter("password");

        LoginDAO dao = new LoginDAO();

        boolean isValid = dao.checkLogin(studentNo, password);

        if (isValid) {
            HttpSession session = req.getSession();
            session.setAttribute("studentNo", Integer.parseInt(studentNo));

            resp.sendRedirect("main");
        } else {
            req.setAttribute("error", "Invalid student number or password");
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
        }
    }
}
