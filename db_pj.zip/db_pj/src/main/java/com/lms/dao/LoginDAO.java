package com.lms.dao;

import java.sql.*;
import com.lms.util.DBUtil;

public class LoginDAO {

    // Temporary login check: only verify student exists
    public boolean checkLogin(String studentNo, String password) {
        String sql = "SELECT COUNT(*) FROM 학생 WHERE 학번 = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, studentNo);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int count = rs.getInt(1);
                return count > 0; // if student exists → login success
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}
