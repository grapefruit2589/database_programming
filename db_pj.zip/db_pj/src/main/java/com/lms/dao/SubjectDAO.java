package com.lms.dao;

import java.sql.*;
import java.util.*;
import com.lms.util.DBUtil;
import com.lms.model.Subject;

public class SubjectDAO {

    // 1) 수강 중인 과목 목록
    public List<Subject> getCurrentSubjects(int studentNo) {
        List<Subject> list = new ArrayList<>();

        String sql =
            "SELECT s.수강ID, c.과목코드, c.과목명 " +
            "FROM 수강중인과목 s " +
            "JOIN 개설과목 o ON s.개설ID = o.개설ID " +
            "JOIN 과목 c ON o.과목코드 = c.과목코드 " +
            "WHERE s.학번 = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, studentNo);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Subject sub = new Subject();
                sub.setEnrollId(rs.getInt("수강ID"));
                sub.setCode(rs.getString("과목코드"));
                sub.setName(rs.getString("과목명"));
                list.add(sub);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    // 2) 과목 상세 정보 조회
    public Map<String, Object> getCourseDetail(int sid) {

        Map<String, Object> map = new HashMap<>();

        String sql =
            "SELECT c.과목명, c.단위, o.학기, o.강의실, " +
            "       t.이름 AS 교사명, t.연락처, s.성적비율 " +
            "FROM 수강중인과목 s " +
            "JOIN 개설과목 o ON s.개설ID = o.개설ID " +
            "JOIN 과목 c ON o.과목코드 = c.과목코드 " +
            "JOIN 교사 t ON o.교번 = t.교번 " +
            "WHERE s.수강ID = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, sid);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                map.put("과목명", rs.getString("과목명"));
                map.put("단위", rs.getInt("단위"));
                map.put("학기", rs.getString("학기"));
                map.put("강의실", rs.getString("강의실"));
                map.put("교사명", rs.getString("교사명"));
                map.put("연락처", rs.getString("연락처"));
                map.put("성적비율", rs.getInt("성적비율"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return map;
    }

    // 3) 동일 개설ID 학생 목록 (학번+이름만)
    public List<Map<String, Object>> getStudentsByCourse(int sid) {

        List<Map<String, Object>> list = new ArrayList<>();

        String sql =
            "SELECT st.학번, st.이름 " +
            "FROM 수강중인과목 s " +
            "JOIN 수강중인과목 s2 ON s2.개설ID = s.개설ID " +
            "JOIN 학생 st ON s2.학번 = st.학번 " +
            "WHERE s.수강ID = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, sid);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("학번", rs.getInt("학번"));
                row.put("이름", rs.getString("이름"));
                list.add(row);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
