package com.lms.dao;

import java.sql.*;
import java.util.*;
import com.lms.util.DBUtil;

public class AchievementDAO {

    // 1) 교과 성취도
	public List<Map<String, Object>> getCourseAchievements(String studentNo) {
	    List<Map<String, Object>> list = new ArrayList<>();

	    String sql =
	        "SELECT c.과목명, s.수강학기 AS 학기, s.성취도 " +
	        "FROM 수강및성취기록 s " +
	        "JOIN 개설과목 o ON s.개설ID = o.개설ID " +
	        "JOIN 과목 c ON o.과목코드 = c.과목코드 " +
	        "WHERE s.학번 = ?";

	    try (Connection conn = DBUtil.getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql)) {

	        ps.setString(1, studentNo);
	        ResultSet rs = ps.executeQuery();

	        while (rs.next()) {
	            Map<String, Object> row = new HashMap<>();
	            row.put("과목명", rs.getString("과목명"));
	            row.put("학기", rs.getString("학기"));
	            row.put("성취도", rs.getString("성취도"));
	            list.add(row);
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return list;
	}



    // 2) 창체활동 성취도
    public List<Map<String,Object>> getActivityAchievements(String studentNo) {
        List<Map<String,Object>> list = new ArrayList<>();

        String sql =
            "SELECT 활동명, 성취도, 학기 " +
            "FROM 창체활동 WHERE 학번 = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, studentNo);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String,Object> row = new HashMap<>();
                row.put("활동명", rs.getString("활동명"));
                row.put("성취도", rs.getString("성취도"));
                row.put("학기", rs.getString("학기"));
                list.add(row);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
